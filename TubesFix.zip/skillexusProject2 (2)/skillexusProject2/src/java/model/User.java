package model;

import java.sql.*;

public class User extends Account {

    public User(String email, String username, String password) {
        super(email, username, password);
    }

    @Override
    public String getUsername() {
        return username;  
    }

    public boolean skillAdd(String name, String category, String description, User user, Connection conn) {
        SetSkill S = new SetSkill();
        boolean H = S.addSkill(name, category, description, user, conn);
        return H;
    }
    
    public boolean sendMessage(String senderUsername, String receiverUsername, String content){
        Message msg = new Message();
        boolean H = msg.sendingMessage(senderUsername, receiverUsername, content);
        return H;
    }
    
    
}
