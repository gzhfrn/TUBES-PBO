package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TradePost {

    private int id;
    private String ownerUsername;
    private int desiredSkillId;
    private int offeredSkillId;
    private String description;

    public TradePost() {
    }

    // Konstruktor tanpa ID saat membuat post baru
    public TradePost(String ownerUsername, int desiredSkillId, int offeredSkillId, String description) {
        this.ownerUsername = ownerUsername;
        this.desiredSkillId = desiredSkillId;
        this.offeredSkillId = offeredSkillId;
        this.description = description;
    }

    // Konstruktor dengan ID saat mengambil data dari database
    public TradePost(int id, String ownerUsername, int desiredSkillId, int offeredSkillId, String description) {
        this.id = id;
        this.ownerUsername = ownerUsername;
        this.desiredSkillId = desiredSkillId;
        this.offeredSkillId = offeredSkillId;
        this.description = description;
    }

    // Getter dan Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOwnerUsername() {
        return ownerUsername;
    }

    public void setOwnerUsername(String ownerUsername) {
        this.ownerUsername = ownerUsername;
    }

    public int getDesiredSkillId() {
        return desiredSkillId;
    }

    public void setDesiredSkillId(int desiredSkillId) {
        this.desiredSkillId = desiredSkillId;
    }

    public int getOfferedSkillId() {
        return offeredSkillId;
    }

    public void setOfferedSkillId(int offeredSkillId) {
        this.offeredSkillId = offeredSkillId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Menambahkan trade post ke database
    public boolean createTradePost(Connection conn) {
        String sql = "INSERT INTO tradepost (owner_username, desired_skill_id, offered_skill_id, description) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, this.ownerUsername);
            stmt.setInt(2, this.desiredSkillId);
            stmt.setInt(3, this.offeredSkillId);
            stmt.setString(4, this.description);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    this.id = generatedKeys.getInt(1); // Set ID hasil auto-increment
                }
                System.out.println("Trade post berhasil dibuat dengan ID: " + this.id);
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Gagal membuat trade post: " + e.getMessage());
        }

        return false;
    }

    // Mengambil semua trade post dari database
    public static List<TradePost> getAllTradePosts(Connection conn) {
        List<TradePost> tradePosts = new ArrayList<>();
        String sql = "SELECT * FROM tradepost ORDER BY id DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                TradePost post = new TradePost(
                        rs.getInt("id"),
                        rs.getString("owner_username"),
                        rs.getInt("desired_skill_id"),
                        rs.getInt("offered_skill_id"),
                        rs.getString("description")
                );
                tradePosts.add(post);
            }

        } catch (SQLException e) {
            System.err.println("Gagal mengambil daftar trade post: " + e.getMessage());
        }

        return tradePosts;
    }

    // Mengambil trade post berdasarkan username
    public static List<TradePost> getTradePostsByOwner(String username, Connection conn) {
        List<TradePost> tradePosts = new ArrayList<>();
        String sql = "SELECT * FROM tradepost WHERE owner_username = ? ORDER BY id DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                TradePost post = new TradePost(
                        rs.getInt("id"),
                        rs.getString("owner_username"),
                        rs.getInt("desired_skill_id"),
                        rs.getInt("offered_skill_id"),
                        rs.getString("description")
                );
                tradePosts.add(post);
            }

        } catch (SQLException e) {
            System.err.println("Gagal mengambil trade post berdasarkan pemilik: " + e.getMessage());
        }

        return tradePosts;
    }

    // Mengambil satu trade post berdasarkan ID
    public static TradePost getTradePostById(int id, Connection conn) {
        String sql = "SELECT * FROM tradepost WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new TradePost(
                        rs.getInt("id"),
                        rs.getString("owner_username"),
                        rs.getInt("desired_skill_id"),
                        rs.getInt("offered_skill_id"),
                        rs.getString("description")
                );
            }

        } catch (SQLException e) {
            System.err.println("Gagal mengambil trade post berdasarkan ID: " + e.getMessage());
        }

        return null;
    }

    // Mengupdate trade post
    public boolean updateTradePost(Connection conn) {
        String sql = "UPDATE tradepost SET desired_skill_id = ?, offered_skill_id = ?, description = ? WHERE id = ? AND owner_username = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, this.desiredSkillId);
            stmt.setInt(2, this.offeredSkillId);
            stmt.setString(3, this.description);
            stmt.setInt(4, this.id);
            stmt.setString(5, this.ownerUsername);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Trade post berhasil diperbarui");
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Gagal mengupdate trade post: " + e.getMessage());
        }

        return false;
    }

    // Menghapus trade post
    public boolean deleteTradePost(Connection conn) {
        String sql = "DELETE FROM tradepost WHERE id = ? AND owner_username = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, this.id);
            stmt.setString(2, this.ownerUsername);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Trade post berhasil dihapus");
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Gagal menghapus trade post: " + e.getMessage());
        }

        return false;
    }

    // Mengambil daftar trade post lengkap dengan detail skill
    public static List<TradePostWithSkills> getTradePostsWithSkillDetails(Connection conn) {
        List<TradePostWithSkills> tradePosts = new ArrayList<>();
        String sql = "SELECT tp.id, tp.owner_username, tp.desired_skill_id, tp.offered_skill_id, tp.description, "
                + "ds.name as desired_skill_name, ds.category as desired_skill_category, ds.description as desired_skill_description, "
                + "os.name as offered_skill_name, os.category as offered_skill_category, os.description as offered_skill_description "
                + "FROM tradepost tp "
                + "JOIN skill ds ON tp.desired_skill_id = ds.id "
                + "JOIN skill os ON tp.offered_skill_id = os.id "
                + "ORDER BY tp.id DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                TradePostWithSkills post = new TradePostWithSkills(
                        rs.getInt("id"),
                        rs.getString("owner_username"),
                        rs.getInt("desired_skill_id"),
                        rs.getInt("offered_skill_id"),
                        rs.getString("description"),
                        rs.getString("desired_skill_name"),
                        rs.getString("desired_skill_category"),
                        rs.getString("desired_skill_description"),
                        rs.getString("offered_skill_name"),
                        rs.getString("offered_skill_category"),
                        rs.getString("offered_skill_description")
                );
                tradePosts.add(post);
            }

        } catch (SQLException e) {
            System.err.println("Gagal mengambil trade post dengan detail skill: " + e.getMessage());
        }

        return tradePosts;
    }

    // Mengambil trade post milik pengguna tertentu dengan detail skill
    public static List<TradePostWithSkills> getMyTradePostsWithSkillDetails(String username, Connection conn) {
        List<TradePostWithSkills> tradePosts = new ArrayList<>();
        String sql = "SELECT tp.id, tp.owner_username, tp.desired_skill_id, tp.offered_skill_id, tp.description, "
                + "ds.name as desired_skill_name, ds.category as desired_skill_category, ds.description as desired_skill_description, "
                + "os.name as offered_skill_name, os.category as offered_skill_category, os.description as offered_skill_description "
                + "FROM tradepost tp "
                + "JOIN skill ds ON tp.desired_skill_id = ds.id "
                + "JOIN skill os ON tp.offered_skill_id = os.id "
                + "WHERE tp.owner_username = ? "
                + "ORDER BY tp.id DESC";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                TradePostWithSkills post = new TradePostWithSkills(
                        rs.getInt("id"),
                        rs.getString("owner_username"),
                        rs.getInt("desired_skill_id"),
                        rs.getInt("offered_skill_id"),
                        rs.getString("description"),
                        rs.getString("desired_skill_name"),
                        rs.getString("desired_skill_category"),
                        rs.getString("desired_skill_description"),
                        rs.getString("offered_skill_name"),
                        rs.getString("offered_skill_category"),
                        rs.getString("offered_skill_description")
                );
                tradePosts.add(post);
            }

        } catch (SQLException e) {
            System.err.println("Gagal mengambil trade post milik pengguna: " + e.getMessage());
        }

        return tradePosts;
    }

    @Override
    public String toString() {
        return "TradePost{" + "id=" + id + ", ownerUsername='" + ownerUsername + '\'' + ", desiredSkillId=" + desiredSkillId + ", offeredSkillId=" + offeredSkillId + ", description='" + description + '\'' + '}';
    }

    // Inner class untuk menampilkan trade post lengkap dengan informasi skill
    public static class TradePostWithSkills {

        private int id;
        private String ownerUsername;
        private int desiredSkillId;
        private int offeredSkillId;
        private String description;
        private String desiredSkillName;
        private String desiredSkillCategory;
        private String desiredSkillDescription;
        private String offeredSkillName;
        private String offeredSkillCategory;
        private String offeredSkillDescription;

        public TradePostWithSkills(int id, String ownerUsername, int desiredSkillId, int offeredSkillId,
                String description, String desiredSkillName, String desiredSkillCategory, String desiredSkillDescription,
                String offeredSkillName, String offeredSkillCategory, String offeredSkillDescription) {
            this.id = id;
            this.ownerUsername = ownerUsername;
            this.desiredSkillId = desiredSkillId;
            this.offeredSkillId = offeredSkillId;
            this.description = description;
            this.desiredSkillName = desiredSkillName;
            this.desiredSkillCategory = desiredSkillCategory;
            this.desiredSkillDescription = desiredSkillDescription;
            this.offeredSkillName = offeredSkillName;
            this.offeredSkillCategory = offeredSkillCategory;
            this.offeredSkillDescription = offeredSkillDescription;
        }

        // Getter
        public int getId() {
            return id;
        }

        public String getOwnerUsername() {
            return ownerUsername;
        }

        public int getDesiredSkillId() {
            return desiredSkillId;
        }

        public int getOfferedSkillId() {
            return offeredSkillId;
        }

        public String getDescription() {
            return description;
        }

        public String getDesiredSkillName() {
            return desiredSkillName;
        }

        public String getDesiredSkillCategory() {
            return desiredSkillCategory;
        }

        public String getDesiredSkillDescription() {
            return desiredSkillDescription;
        }

        public String getOfferedSkillName() {
            return offeredSkillName;
        }

        public String getOfferedSkillCategory() {
            return offeredSkillCategory;
        }

        public String getOfferedSkillDescription() {
            return offeredSkillDescription;
        }

        @Override
        public String toString() {
            return "TradePostWithSkills{" + "id=" + id + ", ownerUsername='" + ownerUsername + '\'' + ", desiredSkill='" + desiredSkillName + " (" + desiredSkillCategory + ")'" + ", offeredSkill='" + offeredSkillName + " (" + offeredSkillCategory + ")'" + ", description='" + description + '\'' + '}';
        }
    }
}