package model;

public interface Register {
    boolean register(String username, String email, String password);
}