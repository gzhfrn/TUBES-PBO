package model;

import java.sql.*;

public class Account implements Login, Register {

    private String email;
    String username;
    private String password;

    public Account(String email, String username, String password) {
        this.email = email;
        this.username = username;
        this.password = password;
    }

    public boolean register(String email, String username, String password) {
        try (Connection conn = DbConnect.getConnection()) {
            conn.setAutoCommit(false);

            // insert akun
            String insertAccount = "INSERT INTO accounts (email, username, password) VALUES (?, ?, ?)";
            PreparedStatement StmtAccount = conn.prepareStatement(insertAccount);
            StmtAccount.setString(1, email);
            StmtAccount.setString(2, username);
            StmtAccount.setString(3, password);
            int accountRows = StmtAccount.executeUpdate();

            System.out.println("Insert ke accounts: " + accountRows);

            // insert user
            String insertUser = "INSERT INTO users (username) VALUES (?)";
            PreparedStatement StmtUser = conn.prepareStatement(insertUser);
            StmtUser.setString(1, username);
            int userRows = StmtUser.executeUpdate();

            System.out.println("Insert ke users: " + userRows);

            if (accountRows > 0 && userRows > 0) {
                conn.commit();
                System.out.println("Registrasi berhasil");
                return true;
            } else {
                conn.rollback();
                System.out.println("Registrasi gagal");
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

    }

    public static Account Login(String username, String password) {
        Account account = null; 

        try (Connection conn = DbConnect.getConnection()) {
            String sql = "SELECT * FROM accounts WHERE username=? AND password=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                account = new Account("", "", "");
                account.setUsername(rs.getString("username"));     
                account.setPassword(rs.getString("password"));     
                account.setEmail(rs.getString("email"));           

                System.out.println("Login berhasil untuk user: " + username);
            } else {
                System.out.println("Login gagal untuk user: " + username);
            }

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("System error: " + e.getMessage());
            e.printStackTrace();
        }

        return account; 
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    @Override
    public Account login(String username, String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
