package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SetSkill {

    private int id;
    private String name;
    private String category;
    private String description;
    
    public SetSkill() {}
    
    public SetSkill(String name, String category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }
    
    // Konstruktor dengan ID, digunakan saat mengambil data dari database
    public SetSkill(int id, String name, String category, String description) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.description = description;
    }
    
    // Menambahkan skill baru ke database
    public boolean addSkill(String name, String category, String description, User user, Connection conn) {
        String sql = "INSERT INTO skill (name, category, description, owner_username) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, category);
            stmt.setString(3, description);
            stmt.setString(4, user.getUsername());

            int rows = stmt.executeUpdate();
            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Mengambil daftar skill berdasarkan username pemilik
    public static List<SetSkill> getSkillsByUsername(String username) {
        List<SetSkill> skills = new ArrayList<>();
        try {
            Connection con = DbConnect.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM skill WHERE owner_username=?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                SetSkill skill = new SetSkill();
                skill.setId(rs.getInt("id"));
                skill.setSkillName(rs.getString("name"));
                skill.setCategory(rs.getString("category"));
                skill.setDescription(rs.getString("description"));
                skills.add(skill);
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return skills;
    }

    // Mengambil semua skill yang tersedia di database diurutkan berdasarkan kategori dan nama
    public static List<SetSkill> getAllSkills(Connection conn) {
        List<SetSkill> skills = new ArrayList<>();
        String sql = "SELECT * FROM skill ORDER BY category, name";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                SetSkill skill = new SetSkill(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("category"),
                    rs.getString("description")
                );
                skills.add(skill);
            }
            
        } catch (SQLException e) {
            System.err.println("Gagal mengambil data skill: " + e.getMessage());
            e.printStackTrace();
        }
        
        return skills;
    }

    // Getter dan Setter

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setSkillName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSkillName() {
        return name;
    }
}