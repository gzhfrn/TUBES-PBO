package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Message {
    private int id;
    private String senderUsername;
    private String receiverUsername;
    private String content;
    private Timestamp timestamp;
    
    // Constructor
    public Message() {}
    
    // Constructor dengan parameter
    public Message(String senderUsername, String receiverUsername, String content) {
        this.senderUsername = senderUsername;
        this.receiverUsername = receiverUsername;
        this.content = content;
        this.timestamp = new Timestamp(System.currentTimeMillis());
    }
    
    // Constructor dengan semua parameter
    public Message(int id, String senderUsername, String receiverUsername, String content, Timestamp timestamp) {
        this.id = id;
        this.senderUsername = senderUsername;
        this.receiverUsername = receiverUsername;
        this.content = content;
        this.timestamp = timestamp;
    }
    
    // untuk mengirim pesan baru
    public boolean sendingMessage(String senderUsername, String receiverUsername, String content) {
        String sql = "INSERT INTO message (sender_username, receiver_username, content, timestamp) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DbConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, senderUsername);
            stmt.setString(2, receiverUsername);
            stmt.setString(3, content);
            stmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
            
            int rows = stmt.executeUpdate();
            return rows > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Untuk mendapatkan semua pesan antara dua user
    public static List<Message> getConversation(String user1, String user2) {
        List<Message> messages = new ArrayList<>();
        String sql = "SELECT * FROM message WHERE " +
                    "(sender_username = ? AND receiver_username = ?) OR " +
                    "(sender_username = ? AND receiver_username = ?) " +
                    "ORDER BY timestamp ASC";
        
        try (Connection conn = DbConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, user1);
            stmt.setString(2, user2);
            stmt.setString(3, user2);
            stmt.setString(4, user1);
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Message message = new Message(
                    rs.getInt("id"),
                    rs.getString("sender_username"),
                    rs.getString("receiver_username"),
                    rs.getString("content"),
                    rs.getTimestamp("timestamp")
                );
                messages.add(message);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return messages;
    }
    
    // method ini untuk mendapatkan daftar lawan bicara dan mengurutkannya berdasarkan pesan terbaru
    
    public static List<String> getConversationPartners(String username) {
        List<String> partners = new ArrayList<>();
        String sql = "SELECT DISTINCT " +
                    "CASE WHEN sender_username = ? THEN receiver_username " +
                    "ELSE sender_username END AS partner, " +
                    "MAX(timestamp) as latest_timestamp " +
                    "FROM message " +
                    "WHERE sender_username = ? OR receiver_username = ? " +
                    "GROUP BY partner " +
                    "ORDER BY latest_timestamp DESC";
        
        try (Connection conn = DbConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            stmt.setString(2, username);
            stmt.setString(3, username);
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                String partner = rs.getString("partner");
                if (!partner.equals(username)) { // Extra safety check
                    partners.add(partner);
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error getting conversation partners: " + e.getMessage());
        }
        
        return partners;
    }
    
    // mendapatkan semua user dari tabel akun, tidak termasuk user saat ini dan semua user yang sudah pernah melakukan percakapan dengannya)
 
    public static List<String> getAllUsers(String currentUser) {
        List<String> users = new ArrayList<>();
        String sql = "SELECT username FROM accounts WHERE username != ? ORDER BY username";
        
        try (Connection conn = DbConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, currentUser);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                users.add(rs.getString("username"));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return users;
    }
    
    // Search users berdasarkan username 
    public static List<String> searchUsers(String searchTerm, String currentUser) {
        List<String> users = new ArrayList<>();
        String sql = "SELECT username FROM accounts WHERE username LIKE ? AND username != ? ORDER BY username LIMIT 10";
        
        try (Connection conn = DbConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, "%" + searchTerm + "%");
            stmt.setString(2, currentUser);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                users.add(rs.getString("username"));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return users;
    }
    
    // cek apakah user ada
    public static boolean userExists(String username) {
        String sql = "SELECT COUNT(*) FROM accounts WHERE username = ?";
        
        try (Connection conn = DbConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    // mendapatkan pesan terakhir dari percakapan
    public static Message getLatestMessage(String user1, String user2) {
        String sql = "SELECT * FROM message WHERE " +
                    "(sender_username = ? AND receiver_username = ?) OR " +
                    "(sender_username = ? AND receiver_username = ?) " +
                    "ORDER BY timestamp DESC LIMIT 1";
        
        try (Connection conn = DbConnect.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, user1);
            stmt.setString(2, user2);
            stmt.setString(3, user2);
            stmt.setString(4, user1);
            
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new Message(
                    rs.getInt("id"),
                    rs.getString("sender_username"),
                    rs.getString("receiver_username"),
                    rs.getString("content"),
                    rs.getTimestamp("timestamp")
                );
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    // method untuk create percakapan pertama kali
    
    public static boolean createConversationIfNotExists(String user1, String user2) {
        // untuk cek apakah percakapan sudah pernah ada
        List<Message> existing = getConversation(user1, user2);
        if (!existing.isEmpty()) {
            return true; // percakapan sudah ada
        }
        
        // Cek apakah percakapan sudah ada
        // return true karena percakapan dibuat saat pesan pertama dikirim
        return true;
    }
    
    // Getters dan Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getSenderUsername() {
        return senderUsername;
    }
    
    public void setSenderUsername(String senderUsername) {
        this.senderUsername = senderUsername;
    }
    
    public String getReceiverUsername() {
        return receiverUsername;
    }
    
    public void setReceiverUsername(String receiverUsername) {
        this.receiverUsername = receiverUsername;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public Timestamp getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    
    // method untuk menampilkan format waktu
    public String getFormattedTimestamp() {
        if (timestamp != null) {
            LocalDateTime ldt = timestamp.toLocalDateTime();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
            return ldt.format(formatter);
        }
        return "";
    }
}