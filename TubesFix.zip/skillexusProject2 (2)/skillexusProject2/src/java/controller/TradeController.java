package controller;

import model.DbConnect;
import model.TradePost;
import model.TradePost.TradePostWithSkills;
import model.SetSkill;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

@WebServlet("/TradeController")
public class TradeController extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        
        if (action == null) {
            action = "list"; 
        }

        switch (action) {
            case "list":
                listTradePosts(request, response);
                break;
            case "myPosts":
                listMyTradePosts(request, response);
                break;
            case "delete":
                deleteTradePost(request, response);
                break;
            case "showCreateForm":
                showCreateForm(request, response);
                break;
            case "showEditForm":
                showEditForm(request, response);
                break;
            default:
                listTradePosts(request, response);
                break;
        }
    }
 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
  
        if (action == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Action parameter is required");
            return;
        }
        
        // Handle action untuk operasi yang mengubah data
        switch (action) {
            case "create":
                createTradePost(request, response);
                break;
            case "update":
                updateTradePost(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
                break;
        }
    }
 /*
     * Method untuk nampilin semua postingan trade dari semua user
     */
    private void listTradePosts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try (Connection conn = DbConnect.getConnection()) {
            List<TradePostWithSkills> tradePosts = TradePost.getTradePostsWithSkillDetails(conn);

            request.setAttribute("tradePosts", tradePosts);
            request.setAttribute("pageType", "all"); 
            request.getRequestDispatcher("TradePage.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Error fetching trade posts: " + e.getMessage());
        }
    }
 /*
     * Method untuk nampilin cuma postingan trade milik user yang lagi login
     */
    private void listMyTradePosts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Cek session user - apakah udah login atau belum?
        HttpSession session = request.getSession(false); 
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String username = (String) session.getAttribute("username");
        
        try (Connection conn = DbConnect.getConnection()) {
            // Ambil cuma postingan milik user ini aja
            List<TradePostWithSkills> myTradePosts = TradePost.getMyTradePostsWithSkillDetails(username, conn);
            
            // Set data buat JSP
            request.setAttribute("tradePosts", myTradePosts);
            request.setAttribute("pageType", "myPosts");
            request.setAttribute("isMyPosts", true);
            
            request.getRequestDispatcher("TradePage.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Error fetching your trade posts: " + e.getMessage());
        }
    }
   /*
     * Method untuk nampilin form create postingan trade baru
     */
    private void showCreateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Cek login dulu - cuma user yang login bisa bikin postingan
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String username = (String) session.getAttribute("username");
        
        try (Connection conn = DbConnect.getConnection()) {
            List<SetSkill> mySkills = model.SetSkill.getSkillsByUsername(username);
            List<SetSkill> allSkills = model.SetSkill.getAllSkills(conn);
        
            request.setAttribute("mySkills", mySkills);
            request.setAttribute("allSkills", allSkills);
            request.setAttribute("formType", "create"); 

            request.getRequestDispatcher("TradeForm.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                             "Error loading create form: " + e.getMessage());
        }
    }
   /*
     * Method untuk nampilin form edit postingan trade yang udah ada
     */
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String username = (String) session.getAttribute("username");
        
        try {
            int postId = Integer.parseInt(request.getParameter("id"));
            
            try (Connection conn = DbConnect.getConnection()) {
                TradePost tradePost = TradePost.getTradePostById(postId, conn);
                
                // Cek apakah postingan ada dan milik user yang login
                if (tradePost != null && tradePost.getOwnerUsername().equals(username)) {
                    // Kalau valid, ambil data skill buat dropdown
                    List<SetSkill> mySkills = model.SetSkill.getSkillsByUsername(username);
                    List<SetSkill> allSkills = model.SetSkill.getAllSkills(conn);
                    
                    request.setAttribute("tradePost", tradePost);
                    request.setAttribute("mySkills", mySkills);
                    request.setAttribute("allSkills", allSkills);
                    request.setAttribute("formType", "edit"); // Kasih tau form ini buat edit
                    
                    request.getRequestDispatcher("TradeForm.jsp").forward(request, response);
                } else {
                    response.sendRedirect("TradeController?action=myPosts&error=unauthorized");
                }
            }
            
        } catch (NumberFormatException e) {
            response.sendRedirect("TradeController?action=myPosts&error=invalid_id");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("TradeController?action=myPosts&error=system_error");
        }
    }
    /*
     * Method untuk proses create postingan trade baru
     */
    private void createTradePost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String username = (String) session.getAttribute("username");
        
        try {
            int desiredSkillId = Integer.parseInt(request.getParameter("desiredSkillId")); // Skill yang diinginkan
            int offeredSkillId = Integer.parseInt(request.getParameter("offeredSkillId")); // Skill yang ditawarin
            String description = request.getParameter("description"); // Deskripsi tambahan
  
            if (description == null || description.trim().isEmpty()) {
                description = "No description provided";
            }
   
            TradePost tradePost = new TradePost(username, desiredSkillId, offeredSkillId, description.trim());
            
            try (Connection conn = DbConnect.getConnection()) {
                if (tradePost.createTradePost(conn)) {
                    response.sendRedirect("TradeController?action=list&success=created");
                } else {
                    response.sendRedirect("TradeController?action=showCreateForm&error=creation_failed");
                }
            }
            
        } catch (NumberFormatException e) {
            response.sendRedirect("TradeController?action=showCreateForm&error=invalid_skill_ids");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("TradeController?action=showCreateForm&error=system_error");
        }
    }
	/*
     * Method untuk proses update postingan trade yang udah ada
     */
	 
    private void updateTradePost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String username = (String) session.getAttribute("username");
        
        try {
            int postId = Integer.parseInt(request.getParameter("id"));
            int desiredSkillId = Integer.parseInt(request.getParameter("desiredSkillId"));
            int offeredSkillId = Integer.parseInt(request.getParameter("offeredSkillId"));
            String description = request.getParameter("description");

            if (description == null || description.trim().isEmpty()) {
                description = "No description provided";
            }
    
            TradePost tradePost = new TradePost(postId, username, desiredSkillId, offeredSkillId, description.trim());
            
            try (Connection conn = DbConnect.getConnection()) {
                if (tradePost.updateTradePost(conn)) {
                    response.sendRedirect("TradeController?action=myPosts&success=updated");
                } else {
                    response.sendRedirect("TradeController?action=showEditForm&id=" + postId + "&error=update_failed");
                }
            }
            
        } catch (NumberFormatException e) {
            response.sendRedirect("TradeController?action=myPosts&error=invalid_data");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("TradeController?action=myPosts&error=system_error");
        }
    }
    
    /*
     * Method untuk hapus postingan trade
     */
    private void deleteTradePost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String username = (String) session.getAttribute("username");
        
        try {
            int postId = Integer.parseInt(request.getParameter("id"));
            
            try (Connection conn = DbConnect.getConnection()) {
                TradePost tradePost = new TradePost();
                tradePost.setId(postId);
                tradePost.setOwnerUsername(username);

                if (tradePost.deleteTradePost(conn)) {
                    response.sendRedirect("TradeController?action=myPosts&success=deleted");
                } else {
                    response.sendRedirect("TradeController?action=myPosts&error=delete_failed");
                }
            }
            
        } catch (NumberFormatException e) {
            response.sendRedirect("TradeController?action=myPosts&error=invalid_id");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("TradeController?action=myPosts&error=system_error");
        }
    }
}