package controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import model.Account;

@WebServlet(name = "RegisControl", urlPatterns = {"/RegisControl"})
public class RegisControl extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Ambil data input dari form (email, username, password)
        String email = request.getParameter("email");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Buat objek Account untuk representasi data user
        Account account = new Account(email, username, password);

        try {
            // Panggil method register untuk proses penyimpanan data ke database
            boolean isSuccess = account.register(email, username, password);

            if (isSuccess) {
                // Kalau berhasil register, kirim pesan sukses dan arahkan ke halaman login
                request.setAttribute("successMessage", "Registrasi berhasil! Silakan login.");
                request.getRequestDispatcher("LoginPage.jsp").forward(request, response);
            } else {
                // Kalau gagal karena email/username udah dipakai, kasih feedback
                request.setAttribute("errorMessage", "Username atau email sudah terdaftar.");
                request.getRequestDispatcher("RegisPage.jsp").forward(request, response);
            }

        } catch (Exception e) {
            // Kalau ada error tak terduga (misalnya koneksi DB error), tampilkan pesan error umum
            e.printStackTrace(); // buat ngecek errornya di console (debugging)
            request.setAttribute("errorMessage", "Terjadi kesalahan sistem.");
            request.getRequestDispatcher("RegisPage.jsp").forward(request, response);
        }
    }
}