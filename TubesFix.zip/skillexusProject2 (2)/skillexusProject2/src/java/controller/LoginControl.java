package controller;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import model.DbConnect;
import model.Account;
@WebServlet(name = "LoginControl", urlPatterns = {"/LoginControl"})
public class LoginControl extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            // Panggil method Login dari model Account
            Account account = Account.Login(username, password);

            if (account != null) {
                // Login berhasil
                request.getSession().setAttribute("username", username);
                request.getSession().setAttribute("account", account); // Simpan object account juga
                response.sendRedirect("DashboardPage.jsp");
            } else {
                // Login gagal
                request.setAttribute("errorMessage", "Username atau password salah.");
                request.getRequestDispatcher("LoginPage.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.html");
        }

    }
}
