package controller;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;
import javax.servlet.annotation.WebServlet;
import model.Message;
import model.User;

@WebServlet(name = "MessagingController", urlPatterns = {"/MessagingController"})
public class MessagingController extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        String currentUser = (session != null) ? (String) session.getAttribute("username") : null;
        
        // Cek apakah user udah login atau belum
        if (currentUser == null) {
            response.sendRedirect("LoginPage.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        String chatWith = request.getParameter("chatWith");
        String searchTerm = request.getParameter("searchTerm");
        
        if ("loadConversation".equals(action) && chatWith != null) {
            // Ambil semua pesan antara user sekarang dan user yang dipilih buat chat
            List<Message> messages = Message.getConversation(currentUser, chatWith);
            request.setAttribute("messages", messages);
            request.setAttribute("chatWith", chatWith);
            request.setAttribute("currentUser", currentUser);
            
            // Ambil daftar temen chat buat ditampilkan di sidebar
            List<String> partners = Message.getConversationPartners(currentUser);
            request.setAttribute("conversationPartners", partners);
                        
            request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
            
        } else if ("searchUsers".equals(action) && searchTerm != null && !searchTerm.trim().isEmpty()) {
            // Fitur cari user buat mulai chat baru
            List<String> searchResults = Message.searchUsers(searchTerm.trim(), currentUser);
            request.setAttribute("searchResults", searchResults);
            request.setAttribute("searchTerm", searchTerm);
            request.setAttribute("currentUser", currentUser);
            
            // Sidebar dan dropdown user
            List<String> partners = Message.getConversationPartners(currentUser);
            request.setAttribute("conversationPartners", partners);
            List<String> allUsers = Message.getAllUsers(currentUser);
            request.setAttribute("allUsers", allUsers);
            
            request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
            
        } else {
            // Kalau gak ada action, tampilkan daftar teman chat aja
            List<String> partners = Message.getConversationPartners(currentUser);
            request.setAttribute("conversationPartners", partners);
            request.setAttribute("currentUser", currentUser);
            List<String> allUsers = Message.getAllUsers(currentUser);
            request.setAttribute("allUsers", allUsers);
            
            request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        String U = (session != null) ? (String) session.getAttribute("username") : null;
        String E = (session != null) ? (String) session.getAttribute("email") : null;
        String P = (session != null) ? (String) session.getAttribute("password") : null;
        String currentUser = (session != null) ? (String) session.getAttribute("username") : null;
        
        // Cek login lagi sebelum proses lebih lanjut
        if (currentUser == null) {
            response.sendRedirect("LoginPage.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        
        if ("sendMessage".equals(action)) {
            String receiverUsername = request.getParameter("receiverUsername");
            String content = request.getParameter("content");
            
            // Cek inputan valid
            if (receiverUsername != null && content != null && !content.trim().isEmpty()) {
                // Cek apakah penerima ada
                if (!Message.userExists(receiverUsername)) {
                    request.setAttribute("error", "User '" + receiverUsername + "' gak ditemukan.");
                    
                    // Kirim data balik ke halaman biar error-nya bisa ditampilkan
                    request.setAttribute("chatWith", receiverUsername);
                    request.setAttribute("currentUser", currentUser);
                    List<String> partners = Message.getConversationPartners(currentUser);
                    request.setAttribute("conversationPartners", partners);
                    List<String> allUsers = Message.getAllUsers(currentUser);
                    request.setAttribute("allUsers", allUsers);
                    
                    request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
                    return;
                }

                // Kirim pesan
                User user = new User(E, U, P);
                boolean success = user.sendMessage(currentUser, receiverUsername, content.trim());
                               
                if (success) {
                    // Kalau berhasil kirim, langsung refresh chat dan sidebar
                    List<Message> messages = Message.getConversation(currentUser, receiverUsername);
                    request.setAttribute("messages", messages);
                    request.setAttribute("chatWith", receiverUsername);
                    request.setAttribute("currentUser", currentUser);
                    
                    List<String> partners = Message.getConversationPartners(currentUser);
                    request.setAttribute("conversationPartners", partners);
                    List<String> allUsers = Message.getAllUsers(currentUser);
                    request.setAttribute("allUsers", allUsers);
                    
                    request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
                } else {
                    // Kalau gagal kirim pesan
                    request.setAttribute("error", "Gagal kirim pesan. Coba lagi ya.");
                    request.setAttribute("chatWith", receiverUsername);
                    request.setAttribute("currentUser", currentUser);
                    
                    List<String> partners = Message.getConversationPartners(currentUser);
                    request.setAttribute("conversationPartners", partners);
                    List<String> allUsers = Message.getAllUsers(currentUser);
                    request.setAttribute("allUsers", allUsers);
                    
                    request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
                }
            } else {
                // Pesan kosong
                request.setAttribute("error", "Isi pesan gak boleh kosong.");
                request.setAttribute("chatWith", receiverUsername);
                request.setAttribute("currentUser", currentUser);
                
                List<String> partners = Message.getConversationPartners(currentUser);
                request.setAttribute("conversationPartners", partners);
                List<String> allUsers = Message.getAllUsers(currentUser);
                request.setAttribute("allUsers", allUsers);
                
                request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
            }
            
        } else if ("startConversation".equals(action)) {
            String targetUser = request.getParameter("targetUser");
            
            // Coba mulai chat baru
            if (targetUser != null && !targetUser.trim().isEmpty()) {
                if (!Message.userExists(targetUser.trim())) {
                    request.setAttribute("error", "User '" + targetUser + "' gak ditemukan.");
                    request.setAttribute("currentUser", currentUser);
                    
                    List<String> partners = Message.getConversationPartners(currentUser);
                    request.setAttribute("conversationPartners", partners);
                    List<String> allUsers = Message.getAllUsers(currentUser);
                    request.setAttribute("allUsers", allUsers);
                    
                    request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
                    return;
                }

                // Kalau user-nya ada, tampilkan chat kosong atau history sebelumnya
                List<Message> messages = Message.getConversation(currentUser, targetUser.trim());
                request.setAttribute("messages", messages);
                request.setAttribute("chatWith", targetUser.trim());
                request.setAttribute("currentUser", currentUser);
                
                List<String> partners = Message.getConversationPartners(currentUser);
                request.setAttribute("conversationPartners", partners);
                List<String> allUsers = Message.getAllUsers(currentUser);
                request.setAttribute("allUsers", allUsers);
                
                request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Masukin username dulu.");
                request.setAttribute("currentUser", currentUser);
                
                List<String> partners = Message.getConversationPartners(currentUser);
                request.setAttribute("conversationPartners", partners);
                List<String> allUsers = Message.getAllUsers(currentUser);
                request.setAttribute("allUsers", allUsers);
                
                request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
            }
            
        } else {
            // Kalau action-nya gak jelas, balik ke halaman utama pesan
            List<String> partners = Message.getConversationPartners(currentUser);
            request.setAttribute("conversationPartners", partners);
            request.setAttribute("currentUser", currentUser);
            List<String> allUsers = Message.getAllUsers(currentUser);
            request.setAttribute("allUsers", allUsers);
            
            request.getRequestDispatcher("MessagePage.jsp").forward(request, response);
        }
    }
}