package controller;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.annotation.WebServlet;

import model.User;
import model.SetSkill;

@WebServlet(name = "SetSkillController", urlPatterns = {"/SetSkillController"})
public class SetSkillController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        String skillName = request.getParameter("skillName");
        String category = request.getParameter("category");
        String description = request.getParameter("description");
        String U = (session != null) ? (String) session.getAttribute("username") : null;
        String E = (session != null) ? (String) session.getAttribute("email") : null;
        String P = (session != null) ? (String) session.getAttribute("password") : null;
        User user = new User(E, U, P);
        
        if (user == null) {
            response.sendRedirect("LoginPage.jsp");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/db_skilllexus", "root", "");

            boolean success = user.skillAdd(skillName, category, description, user, conn);

            conn.close();

            if (success) {
                response.sendRedirect("SetSkillPage.jsp?status=skillAdded");
            } else {
                response.sendRedirect("SetSkillPage.jsp?error=addFailed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("SetSkillPage.jsp?error=serverError");
        }
    }
}
