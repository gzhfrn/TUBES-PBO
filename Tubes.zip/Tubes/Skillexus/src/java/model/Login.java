package model;

public interface Login {
    Account login(String username, String password);
}