package main;

public class TradeRequest {
    
}
