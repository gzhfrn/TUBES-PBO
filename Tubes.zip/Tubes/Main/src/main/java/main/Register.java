package main;

public interface Register {
    public void register(Account a);
}
