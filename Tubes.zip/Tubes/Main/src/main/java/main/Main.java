
package main;
import javax.swing.*;

public class Main {
    
    public static void main(String[] args) {
        LoginForm loginFrame = new LoginForm();
        loginFrame.setVisible(true);
        loginFrame.pack();
        loginFrame.setLocationRelativeTo(null);
    }
}
