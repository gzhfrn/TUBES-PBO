package main;

public class TradePost {
    
}
