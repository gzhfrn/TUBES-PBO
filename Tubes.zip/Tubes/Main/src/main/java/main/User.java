package main;
import java.util.ArrayList;
public class User extends Account{
    private static ArrayList<Message> msg = new ArrayList<>();
    private static ArrayList<Skill> skl = new ArrayList<>();
    private static ArrayList<TradePost> TrP = new ArrayList<>();
    private static ArrayList<TradeRequest> TrR = new ArrayList<>();
    
    public User(String username, String password, String email) {
        super(username, password, email);
    }
    
    public TradeRequest proposeTrade(Skill S, TradePost T){
        TradeRequest TR = new TradeRequest();
        return TR;
    }
}
