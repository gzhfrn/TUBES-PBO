package main;

public class Message {
    
}
