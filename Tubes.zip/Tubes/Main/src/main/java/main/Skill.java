package main;

public class Skill {
    String name;
    String category;
    String description;

    public Skill(String name, String category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }
}
