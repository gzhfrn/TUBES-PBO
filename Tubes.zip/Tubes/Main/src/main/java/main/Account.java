package main;
import javax.swing.*;
import java.util.ArrayList;
public class Account implements Login, Register{
    private String username;
    private String password;
    private String email;
    private static ArrayList<Account> listAcc = new ArrayList<>();
    
    public Account(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    @Override
    public String toString() {
        return "Username: " + username + ", Password: " + password + ", Email: " + email;
    }
    
    public void login(String username, String password){
        
    }
    
    public static boolean checkArray(String username, String password){
        for (Account acc : listAcc) {
            if (acc.getUsername().equals(username) && acc.getPassword().equals(password)) {
                return true; // Login successful
            }
        }
        return false; // No match found
    }
    
    public void register(Account a){
        
        RegisterForm rgf = new RegisterForm();
        rgf.setVisible(true);
        rgf.pack();
        rgf.setLocationRelativeTo(null);
        if(a.username != null && !a.username.isEmpty() && a.password != null && !a.password.isEmpty() && a.email != null && !a.email.isEmpty()){
            listAcc.add(a);
        }
        System.out.println(listAcc);
    }
        
}
