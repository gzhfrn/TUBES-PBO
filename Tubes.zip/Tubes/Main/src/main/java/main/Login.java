package main;

public interface Login {
    public void login(String username, String password);
}
